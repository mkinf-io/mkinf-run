"""DuckDuckGo Search API toolkit."""

from ddg_search.utils.duckduckgo_search import DuckDuckGoSearchAPIWrapper

__all__ = ["DuckDuckGoSearchAPIWrapper"]