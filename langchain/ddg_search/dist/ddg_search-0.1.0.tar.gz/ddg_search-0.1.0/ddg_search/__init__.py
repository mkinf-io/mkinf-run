"""DuckDuckGo Search API toolkit."""

from ddg_search.tool import DuckDuckGoSearchRun

__all__ = ["DuckDuckGoSearchRun"]

